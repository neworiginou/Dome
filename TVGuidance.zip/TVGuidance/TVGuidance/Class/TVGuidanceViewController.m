//
//  TVGuidanceViewController.m
//  TVGuidance
//
//  Created by lben on 15/6/12.
//  Copyright (c) 2015年 lben. All rights reserved.
//

#import "TVGuidanceViewController.h"
#import "TVGuidancePage.h"
#import "TVGuidancePageViewController.h"

#define kAnimationDuration .3

@interface TVGuidanceViewController ()<UIScrollViewDelegate,UIPageViewControllerDataSource,UIPageViewControllerDelegate>
@property (weak, nonatomic) UIScrollView * scrollView;
@property (strong, nonatomic) NSMutableArray * pageItems;
@property (weak, nonatomic) UIPageViewController * pageViewController;
@property (weak, nonatomic) UIPageControl * pageControl;
@end

@implementation TVGuidanceViewController

- (instancetype)initWithItems:(NSArray *)items{
    self = [self init];
    if (self) {
        [self pInitData];
    }
    return self;
}

- (instancetype)init
{
    self = [super init];
    if (self) {
        [self pInitData];
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
//    [self pMakeScrollView];
    [self pMakePageConroller];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    TVGuidancePageViewController * vc = [self.pageViewController.viewControllers lastObject];
    [vc showAnimationWithDuration:kAnimationDuration];
}

#pragma mark - static  view

- (void)pInitData{
    TVGuidancePage * page_1 = [[TVGuidancePage alloc] initWithBackgroundPictureName:@"1" duation:.3 centerImageName:nil animationType:TVGuidancePageTypeLaunch];
    TVGuidancePage * page_2 = [[TVGuidancePage alloc] initWithBackgroundPictureName:@"2" duation:.3 centerImageName:nil animationType:TVGuidancePageTypeLaunch];
    TVGuidancePage * page_3 = [[TVGuidancePage alloc] initWithBackgroundPictureName:@"3" duation:.3 centerImageName:nil animationType:TVGuidancePageTypeLaunch];
    TVGuidancePage * page_4 = [[TVGuidancePage alloc] initWithBackgroundPictureName:@"4" duation:.3 centerImageName:nil animationType:TVGuidancePageTypeLaunchHome];
    [self.pageItems addObject:page_1];
    [self.pageItems addObject:page_2];
    [self.pageItems addObject:page_3];
    [self.pageItems addObject:page_4];
}

- (void)pMakePageConroller{
    UIPageViewController * pageViewController = ({
        UIPageViewController * pageViewController = [[UIPageViewController alloc] init];
        NSDictionary *options =[NSDictionary dictionaryWithObject:[NSNumber numberWithInteger:UIPageViewControllerSpineLocationMin]
                                                           forKey: UIPageViewControllerOptionSpineLocationKey];
        pageViewController = [[UIPageViewController alloc] initWithTransitionStyle:UIPageViewControllerTransitionStyleScroll
                                                             navigationOrientation:UIPageViewControllerNavigationOrientationHorizontal
                                                                           options: options];
        TVGuidancePageViewController *initialViewController =[self viewControllerAtIndex:0];// 得到第一页
        NSArray *viewControllers =[NSArray arrayWithObject:initialViewController];
        [pageViewController setViewControllers:viewControllers
                                     direction:UIPageViewControllerNavigationDirectionForward
                                      animated:NO
                                    completion:nil];
        [self addChildViewController:pageViewController];
        [self.view addSubview:pageViewController.view];
        pageViewController.delegate = self;
        pageViewController.dataSource = self;
        [pageViewController.view setFrame:self.view.bounds];
        pageViewController;
    });
    self.pageViewController = pageViewController;
    
    
//    UIPageControl * pageControl = ({
//        UIPageControl * pageControl = [[UIPageControl alloc] init];
//        [self.view addSubview:pageControl];
//        pageControl.backgroundColor = [UIColor grayColor];
//        pageControl.numberOfPages = 4;
//        pageControl.translatesAutoresizingMaskIntoConstraints = NO;
//        [self.view addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"H:[pageControl(==200)]" options:0 metrics:nil views:NSDictionaryOfVariableBindings(pageControl)]];
//        [self.view addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:[pageControl(==30)]-20-|" options:0 metrics:nil views:NSDictionaryOfVariableBindings(pageControl)]];
//        [self.view addConstraint:[NSLayoutConstraint constraintWithItem:pageControl attribute:NSLayoutAttributeCenterX relatedBy:NSLayoutRelationEqual toItem:self.view attribute:NSLayoutAttributeCenterX multiplier:1.0 constant:0.0]];
//        pageControl;
//    });
//    self.pageControl = pageControl;
}

- (void)pMakeScrollView{
    UIScrollView * scrollView = ({
        UIScrollView * scrollView = [[UIScrollView alloc] init];
        scrollView.frame = self.view.bounds;
        scrollView.pagingEnabled = YES;
        scrollView.contentSize = CGSizeMake([self.pageItems count] * CGRectGetWidth(self.view.frame), scrollView.contentSize.height);
        [self.view addSubview:scrollView];
        scrollView.delegate = self;
        scrollView;
    });
    self.scrollView = scrollView;
}

- (NSMutableArray *)pageItems{
    if (!_pageItems) {
        _pageItems = [[NSMutableArray alloc] init];
    }
    return _pageItems;
}

// 得到相应的VC对象
- (TVGuidancePageViewController *)viewControllerAtIndex:(NSUInteger)index {
    if (([self.pageItems count] == 0) || (index >= [self.pageItems count])) {
        return nil;
    }
    TVGuidancePage * page = [self.pageItems objectAtIndex:index];
    TVGuidancePageViewController *dataViewController =[[TVGuidancePageViewController alloc] initWithIndex:index pageType:page.pageType];
    return dataViewController;
}

- (NSInteger)presentationIndexForPageViewController:(UIPageViewController *)pageViewController{
    return 1;
}

#pragma mark- UIPageViewControllerDataSource

// 返回上一个ViewController对象
- (TVGuidancePageViewController *)pageViewController:(UIPageViewController *)pageViewController viewControllerBeforeViewController:(TVGuidancePageViewController *)viewController{
    
    [viewController showAnimationWithDuration:kAnimationDuration];
    NSUInteger index = viewController.index;
    NSLog(@"----pro---->%ld",index);
    if ((index == 0) || (index == NSNotFound)) {
        return nil;
    }
    
    index--;
    TVGuidancePageViewController  * proPageViewController = [self viewControllerAtIndex:index];
    return proPageViewController;
}

// 返回下一个ViewController对象
- (TVGuidancePageViewController *)pageViewController:(UIPageViewController *)pageViewController viewControllerAfterViewController:(TVGuidancePageViewController *)viewController{
    
    [viewController showAnimationWithDuration:kAnimationDuration];
    NSUInteger index = viewController.index;
    NSLog(@"----next---->%ld",index);
    if (index == NSNotFound) {
        return nil;
    }
    
    index++;
    if (index == [self.pageItems count]) {
        return nil;
    }
    TVGuidancePageViewController * nextPageViewController = [self viewControllerAtIndex:index];
    return nextPageViewController;
}

@end
